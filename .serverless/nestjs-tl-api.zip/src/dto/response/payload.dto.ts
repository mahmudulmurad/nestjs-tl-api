export class PayloadDto {
    // eslint-disable-next-line @typescript-eslint/ban-types
    constructor(public count: number = 0, public data: Object = []) {}
  }
  