export class SystemErrorDto {
    constructor(
      public domain: string,
      public value: string,
      public message: string,
    ) {}
  }
  