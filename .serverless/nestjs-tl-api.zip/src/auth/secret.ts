export const jwtConstants = {
    secret: 'a89@#ja34923y2***8wq6e2738',
  };