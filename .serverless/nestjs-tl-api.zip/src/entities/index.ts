import {User} from './user/user.entity'
import { Product } from './product/product.entity'

export {
    User,
    Product
}